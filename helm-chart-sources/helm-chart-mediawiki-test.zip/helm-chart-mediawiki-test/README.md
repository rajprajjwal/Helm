# Helm Chart for deploying Mediawiki v1.34
